def mock_db_read(query):
    pass